# ContentErrorType

Type of content that encountered an error

## Enum

* `PROMPT` (value: `'prompt'`)

* `RESPONSE` (value: `'response'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


